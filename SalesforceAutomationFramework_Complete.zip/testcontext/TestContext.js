
function TestContext() {
  this.browser = null;
  this.sessionId = null;
}

module.exports = TestContext;
