# Salesforce Automation Framework

This framework uses TestComplete with JavaScript.

**Project Structure**:
- config: configuration files
- pages: Page Object Model scripts
- utils: Logger and assertion utilities
- testcontext: test run context
- reports: Allure reports output
- tests: Test scripts

**Usage**:
- Install dependencies
- Update config/config.json for browser and base URL
- Add Page Objects and tests
- Use TestRunner.js to run tests
