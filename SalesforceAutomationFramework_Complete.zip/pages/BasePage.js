
function BasePage() {
  this.waitForVisible = function(element, timeout) {
    timeout = timeout || 10000;
    var start = new Date().getTime();
    while (!element.Exists || !element.VisibleOnScreen) {
      if (new Date().getTime() - start > timeout) {
        Log.Error("Element not visible after " + timeout + "ms");
        return false;
      }
      Delay(500);
    }
    return true;
  };

  this.setText = function(element, text) {
    if (this.waitForVisible(element)) {
      element.SetText(text);
    }
  };

  this.click = function(element) {
    if (this.waitForVisible(element)) {
      element.Click();
    }
  };
}

module.exports = BasePage;
