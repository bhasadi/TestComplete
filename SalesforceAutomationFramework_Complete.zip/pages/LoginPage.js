
var BasePage = require("pages\\BasePage");

function LoginPage() {
  var base = new BasePage();

  this.usernameInput = function() { return Aliases.browser.pageLogin.textboxUsername; };
  this.passwordInput = function() { return Aliases.browser.pageLogin.textboxPassword; };
  this.loginButton = function() { return Aliases.browser.pageLogin.buttonLogin; };

  this.login = function(username, password) {
    base.setText(this.usernameInput(), username);
    base.setText(this.passwordInput(), password);
    base.click(this.loginButton());
  };
}

module.exports = LoginPage;
