
var LoginPage = require("pages\\LoginPage");
var logger = require("utils\\Logger");
var config = require("config\\Config").getConfig();

function Test_Login_Success() {
  logger.info("Starting Login Test");

  Browsers.Item(config.browser).Run(config.baseUrl);
  var page = Aliases.browser.pageLogin;
  page.Wait();

  var loginPage = new LoginPage();
  loginPage.login("testuser", "password");

  logger.info("Login Test Completed");
}
