
function getConfig() {
  var configFile = Project.Path + "config\\config.json";
  var fso = new ActiveXObject("Scripting.FileSystemObject");
  var file = fso.OpenTextFile(configFile, 1);
  var content = file.ReadAll();
  file.Close();
  return JSON.parse(content);
}

module.exports = { getConfig };
