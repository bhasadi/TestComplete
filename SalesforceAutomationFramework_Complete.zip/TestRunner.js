
function runTest(testFunc) {
  try {
    Log.AppendFolder("Test: " + testFunc.name);
    testFunc();
    Log.PopLogFolder();
  } catch (e) {
    Log.Error("Test failed: " + e.message);
  }
}

module.exports = { runTest };
