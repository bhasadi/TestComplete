
// TestContext.js
function TestContext() {
  this.browser = null;
}
module.exports = TestContext;
